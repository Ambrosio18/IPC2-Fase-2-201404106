﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IPC2Vacaciones
{
    public partial class Formulario_web14 : System.Web.UI.Page
    {
        WebService.WebServiceFase2Client conex = new WebService.WebServiceFase2Client();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string identificacion = Convert.ToString(TextBox1.Text);
            string tipo = Convert.ToString(DropDownList1.Text);
            string nuevacontra = Convert.ToString(TextBox2.Text);
            string contra = Convert.ToString(TextBox3.Text);
            if (nuevacontra == contra)
            {
                conex.CambiarContra(contra, identificacion);
            }
            else
            {
                Console.WriteLine("las contraseñas no coinciden");
            }
        }
    }
}