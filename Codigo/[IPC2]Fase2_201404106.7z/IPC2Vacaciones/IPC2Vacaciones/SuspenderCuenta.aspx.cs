﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IPC2Vacaciones
{
    public partial class Formulario_web111 : System.Web.UI.Page
    {
        WebService.WebServiceFase2Client conex = new WebService.WebServiceFase2Client();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string id = Convert.ToString(TextBox1.Text);
            string tipo = Convert.ToString(DropDownList1.Text);
            conex.SuspenderActivar("Suspendida", id, tipo);
        }
    }
}