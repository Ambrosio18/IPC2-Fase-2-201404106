﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IPC2Vacaciones
{
    public partial class Formulario_web110 : System.Web.UI.Page
    {
        WebService.WebServiceFase2Client conex = new WebService.WebServiceFase2Client();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string tipo = Convert.ToString(TextBox1.Text);
            string fecha = Convert.ToString(TextBox2.Text);
            string detalle = Convert.ToString(TextBox3.Text);
            string trabajador = Convert.ToString(TextBox4.Text);
            string cliente = Convert.ToString(TextBox6.Text);
            string tipocuenta = Convert.ToString(TextBox5.Text);
            conex.solicitud("", tipo, fecha, detalle, trabajador, cliente, tipocuenta);
        }
    }
}