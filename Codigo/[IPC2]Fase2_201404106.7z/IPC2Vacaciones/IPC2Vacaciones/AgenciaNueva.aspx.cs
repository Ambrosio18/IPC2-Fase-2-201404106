﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IPC2Vacaciones
{
    public partial class Formulario_web11 : System.Web.UI.Page
    {
        WebService.WebServiceFase2Client conex = new WebService.WebServiceFase2Client();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string direccion = Convert.ToString(TextBox1.Text);
            string telefono = Convert.ToString(TextBox2.Text);
            conex.CrearAgencia(direccion, telefono);
        }
    }
}