﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IPC2Vacaciones
{
    public partial class Formulario_web12 : System.Web.UI.Page
    {
        WebService.WebServiceFase2Client conex = new WebService.WebServiceFase2Client();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string cui = Convert.ToString(TextBox1.Text);
            string nombre = Convert.ToString(TextBox2.Text);
            string apellido = Convert.ToString(TextBox3.Text);
            string telefono = Convert.ToString(TextBox4.Text);
            string correo = Convert.ToString(TextBox5.Text);
            string tipo = Convert.ToString(DropDownList1.Text);
            string usuario = Convert.ToString(TextBox6.Text);
            string contra = Convert.ToString(TextBox7.Text);
            string agencia = Convert.ToString(TextBox8.Text);

            conex.CrearTrabajador(cui, nombre, apellido, telefono, correo, tipo, usuario, contra, agencia);
        }
    }
}