/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;
import ConexionBD.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
/**
 *
 * @author AmbrosioAlemán
 */
public class login {
    public Boolean logearse(String usuario, String contrasena) {
        Conexion conec = new Conexion();
        Connection conexion = conec.getDBConection();
        
        

        try {
            Statement query = conexion.createStatement();
            ResultSet rs = query.executeQuery("SELECT usuario,contraseña FROM  clientes");
            String nombre, pass;
            while (rs.next()) {
                nombre = rs.getString("usuario");
                pass = rs.getString("contraseña");
                if (pass.equals(contrasena)) {
                    return true;
                } else {
                    return false;
                }

            }
            rs.close();
            conexion.close();
                    
        } catch (Exception e) {
            return false;
        }
        return false;
    }
    
}
