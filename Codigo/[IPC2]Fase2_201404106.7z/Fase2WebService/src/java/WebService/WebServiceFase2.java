/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebService;

import ConexionBD.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author AmbrosioAlemán
 */
@WebService(serviceName = "WebServiceFase2")
public class WebServiceFase2 {
    Conexion conex = new Conexion();

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
    @WebMethod(operationName = "CrearCliente")
    public String CrearCliente(@WebParam(name = "cui") String cui, @WebParam(name = "nombre") String nombre, @WebParam(name = "apellido") String apellido, @WebParam(name = "fechaNacimiento") String fechaNacimiento, @WebParam(name = "direccion") String direccion, @WebParam(name = "Telefono") Integer telefono, @WebParam(name = "Correo") String Correo, @WebParam(name = "usuario") String usuario, @WebParam(name = "Contrase\u00f1a") String Contraseña) {
        Conexion conec = new Conexion();
        Connection conexion = conec.getDBConection();
        int consulta = 0;
        String consulta1 ="";
        try{
            Statement query = conexion.createStatement();
               consulta = query.executeUpdate("Insert Into clientes (cui, nombre, apellido, fecha_de_nacimiento, direccion, telefono, correo, usuario, contraseña)"+
                       "Values("+cui+",'"+nombre+"', '"+apellido+"', '"+fechaNacimiento+"', '"+direccion+"',"+telefono+", '"+Correo+"', '"+usuario+"', '"+Contraseña+"');");
               conexion.close();
        }catch(Exception ex){
            System.out.println("conexion incorrecta"+ex);
        }
        
        return consulta1;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "CrearCuenta")
    public String CrearCuenta(@WebParam(name = "tipocuenta") String tipocuenta, @WebParam(name = "interes") String interes, @WebParam(name = "estadoCuenta") String estadoCuenta,@WebParam(name = "total") String total, @WebParam(name = "cliente") String cliente) {
        Conexion conec = new Conexion();
        Connection conexion = conec.getDBConection();
        int consulta = 0;
        String consulta1 ="";
        try{
            Statement query = conexion.createStatement();
               //consulta = query.executeUpdate("SELECT nombre FROM patrocinador");
               consulta= query.executeUpdate("INSERT INTO CUENTA (id_cuenta, tipo_cuenta, interes, estado_cuenta,Total, clientes_cui)"+
                      "VALUES(null,'"+tipocuenta+"','"+interes+"','"+estadoCuenta+"','"+total+"',"+cliente+");");
               
                conexion.close();
        }catch(Exception ex){
            System.out.println("conexion incorrecta"+ex);
        }
        
        return consulta1;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "CambiarContra")
    public String CambiarContra(@WebParam(name = "contra") String contra, @WebParam(name = "cliente") String cliente) {
        Conexion conec = new Conexion();
        Connection conexion = conec.getDBConection();
        int consulta = 0;
        String consulta1 ="";
        try{
            Statement query = conexion.createStatement();
               //consulta = query.executeUpdate("SELECT nombre FROM patrocinador");
               consulta = query.executeUpdate("update clientes set contraseña='"+contra+"'  where cui="+cliente+";");
               conexion.close();
        }catch(Exception ex){
            System.out.println("conexion incorrecta"+ex);
        }
        return consulta1;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "CrearAgencia")
    public String CrearAgencia(@WebParam(name = "direccion") String direccion, @WebParam(name = "telefono") String telefono) {
       Conexion conec = new Conexion();
        Connection conexion = conec.getDBConection();
        int consulta = 0;
        String consulta1 ="";
        try{
            Statement query = conexion.createStatement();
               //consulta = query.executeUpdate("SELECT nombre FROM patrocinador");
               consulta = query.executeUpdate("INSERT INTO AGENCIA (id_agencia, direccion, telefono)" +
                    "VALUES (null, '"+direccion+"',"+telefono+");");
               conexion.close();
        }catch(Exception ex){
            System.out.println("conexion incorrecta"+ex);
        }
        return consulta1;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "CrearTrabajador")
    public String CrearTrabajador(@WebParam(name = "idTrabajador") String idTrabajador, @WebParam(name = "nombre") String nombre, @WebParam(name = "apellido") String apellido, @WebParam(name = "telefono") String telefono, @WebParam(name = "correo") String correo, @WebParam(name = "tipoTrabajador") String tipoTrabajador, @WebParam(name = "usuario") String usuario, @WebParam(name = "contrase\u00f1a") String contraseña, @WebParam(name = "agencia") String agencia) {
        Conexion conec = new Conexion();
        Connection conexion = conec.getDBConection();
        int consulta = 0;
        String consulta1 ="";
        try{
            Statement query = conexion.createStatement();
               //consulta = query.executeUpdate("SELECT nombre FROM patrocinador");
               consulta = query.executeUpdate("INSERT INTO TRABAJADOR (id_trabajador, nombre, apellido,telefono,correo,tipotrabajador,usuario,contraseña,agencia_id_agencia)" +
                            "VALUES (null, '"+nombre+"','"+apellido+"',"+telefono+", '"+correo+"','"+tipoTrabajador+"','"+usuario+"', '"+contraseña+"','"+agencia+"');");
               conexion.close();
        }catch(Exception ex){
            System.out.println("conexion incorrecta"+ex);
        }
        return consulta1;
    }   

    /**
     * Web service operation
     */
    @WebMethod(operationName = "SuspenderActivar")
    public String SuspenderActivar(@WebParam(name = "Estado") String Estado, @WebParam(name = "cliente") String cliente, @WebParam(name = "tipo") String tipo) {
       Conexion conec = new Conexion();
        Connection conexion = conec.getDBConection();
        int consulta = 0;
        String consulta1 ="";
        try{
            Statement query = conexion.createStatement();
               //consulta = query.executeUpdate("SELECT nombre FROM patrocinador");
              consulta = query.executeUpdate("update cuenta set estado_cuenta= '"+Estado+"' where clientes_cui="+cliente+"and tipo_cuenta="+tipo+";");
               conexion.close();
        }catch(Exception ex){
            System.out.println("conexion incorrecta"+ex);
        }
        return consulta1;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "solicitud")
    public String solicitud(@WebParam(name = "id_solicitud") String id_solicitud, @WebParam(name = "tipo_solicitud") String tipo_solicitud, @WebParam(name = "fecha") String fecha, @WebParam(name = "detalle") String detalle, @WebParam(name = "trabajadorid") String trabajadorid, @WebParam(name = "cliente") String cliente,@WebParam(name = "tipocuenta") String tipocuenta) {
        Conexion conec = new Conexion();
        Connection conexion = conec.getDBConection();
        int consulta = 0;
        String consulta1 ="";
        try{
            Statement query = conexion.createStatement();
               //consulta = query.executeUpdate("SELECT nombre FROM patrocinador");
            ResultSet rs = query.executeQuery("Select id_cuenta from cuenta where clientes_cui="+cliente+" and tipo_cuenta='"+tipocuenta+"';");
               while(rs.next()){
                   consulta1 += rs.getString("id_cuenta");
               }
              consulta = query.executeUpdate("Insert Into solicitud (id_solicitud, tipo_solicitud, fechar, detalle, trabajador_id_trabajador, cuenta_id_cuenta)" +
                    "Values (null,'"+tipo_solicitud+"', '"+fecha+"', '"+detalle+"','"+trabajadorid+"','"+consulta1+"');");
               conexion.close();
        }catch(Exception ex){
            System.out.println("conexion incorrecta"+ex);
        }
        return consulta1;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "DepositoCheque")
    public String DepositoCheque(@WebParam(name = "fecha") String fecha, @WebParam(name = "cheque") String cheque, @WebParam(name = "monto") String monto, @WebParam(name = "cuentacheque") String cuentacheque, @WebParam(name = "cuentadeposito") String cuentadeposito,@WebParam(name = "tipocuenta") String tipocuenta) {
      Conexion conec = new Conexion();
        Connection conexion = conec.getDBConection();
        int consulta = 0;
        int nuevotot=0;
        int montoa=0;
        String totaln="";
        String consulta1 ="";
        try{
            Statement query = conexion.createStatement();
               //consulta = query.executeUpdate("SELECT nombre FROM patrocinador");
            ResultSet rs = query.executeQuery("Select total from cuenta where clientes_cui="+cuentadeposito+" and tipo_cuenta='"+tipocuenta+"';");
               while(rs.next()){
                   consulta1 += rs.getString("total");
               }
               try{
                   consulta = Integer.parseInt(consulta1);
                   montoa = Integer.parseInt(monto);
               }catch(Exception te){
                   System.out.println("no se pudo convertir");
               }
               nuevotot=consulta + montoa;
               totaln = String.valueOf(nuevotot);
              consulta = query.executeUpdate("update cuenta set total="+totaln+"where clientes_cui="+cuentadeposito+"and tipo_cuenta="+tipocuenta+";");
               conexion.close();
        }catch(Exception ex){
            System.out.println("conexion incorrecta"+ex);
        }
        return consulta1;
    }
}
